package com.bueng.healthyhelpers;

public class Recipe {
    public String recipeName;        //name of recipe
    public String ingredients;       //ingredients list
    public String userIngredients;   //ingredients with measurements
    public String instructions;      //recipe instructions
    public String link;              //recipe source

    public Recipe(){
    }

    public Recipe(String recipeName, String ingredients, String userIngredients, String instructions, String link) {
        this.recipeName = recipeName;
        this.ingredients = ingredients;
        this.userIngredients = userIngredients;
        this.instructions = instructions;
        this.link = link;
    }
}