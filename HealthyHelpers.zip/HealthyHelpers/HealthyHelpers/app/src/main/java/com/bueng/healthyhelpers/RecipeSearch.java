package com.bueng.healthyhelpers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;

public class RecipeSearch extends AppCompatActivity {

    private CheckBox vgt, vg;
    public static final String[] restriction = new String[1];
    public static final String[] ingredient1 = new String[1];
    public static final String[] ingredient2 = new String[1];
    public static final String[] ingredient3 = new String[1];
    public static final String[] ingredient4 = new String[1];
    public static final String[] ingredient5 = new String[1];
    public static final String[] ingredient6 = new String[1];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_search);


        Button btn2 = (Button) findViewById(R.id.button_recipe_find);

        //Set up button
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDisplay();
            }
        });

        // DIETARY RESTRICTIONS
        //View needs fixing

        vgt = findViewById(R.id.checkBoxvgt);
        vg = findViewById(R.id.checkBoxvg);

        restriction[0] = "other";

        vgt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(vgt.isChecked())
                    restriction[0] = "vegetarian";
            }
        });

        vg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(vg.isChecked())
                    restriction[0] = "vegan";
            }
        });
//
//        public void onCheckboxClicked(View view) {
//        // is view checked?
//        boolean checked = ((CheckBox) view).isChecked();
//            // check which checkbox was clicked
//            switch (view.getId()) {
//                case R.id.checkBoxvg: //VEGAN
//                    if (checked) {
//                        // only access vegan recipes
//                        restriction[0] = "vegan";
//                    } else {
//                        //access all recipes
//                        restriction[0] = "other";
//                    }
//                    break;
//                case R.id.checkBoxvgt: //VEGETARIAN
//                    if (checked) {
//                        // only access vegetarian recipes
//                        restriction[0] = "";
//                    } else {
//                        // access all recipes
//                        restriction[0] = "other";
//                    }
//                    break;
//            }
//        }

        //Definition of spinners --> ingredient drop down menus
        final Spinner spinner1 = findViewById(R.id.spinner2); //vegetables
        final Spinner spinner2 = findViewById(R.id.spinner); //proteins
        final Spinner spinner3 = findViewById(R.id.spinner3); //fruits
        final Spinner spinner4 = findViewById(R.id.spinner4); //nuts and seeds
        final Spinner spinner5 = findViewById(R.id.spinner5); //dairy and alternatives
        final Spinner spinner6 = findViewById(R.id.spinner6); //carbohydrates

        // VEGETABLES
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.vegetables_array, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                parent.getItemAtPosition(position);
                ingredient1[0] = spinner1.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
                ingredient1[0] = " ";
            }
        });


        // PROTEINS
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.protein_array, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient2[0] = spinner2.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
                ingredient2[0] = " ";
            }
        });

        // FRUITS
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,
                R.array.fruit_array, android.R.layout.simple_spinner_item);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter3);
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient3[0] = spinner3.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
                ingredient3[0] = " ";
            }
        });

        // NUTS AND SEEDS
        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this,
                R.array.nuts_array, android.R.layout.simple_spinner_item);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner4.setAdapter(adapter4);
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient4[0] = spinner4.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
                ingredient4[0] = " ";
            }
        });

        // DAIRY AND ALTERNATIVES
        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this,
                R.array.dairy_array, android.R.layout.simple_spinner_item);
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner5.setAdapter(adapter5);
        spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient5[0] = spinner5.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
                ingredient5[0] = " ";
            }
        });

        //  CARBOHYDRATES
        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this,
                R.array.carbs_array, android.R.layout.simple_spinner_item);
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner6.setAdapter(adapter6);
        spinner6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient6[0] = spinner6.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
                ingredient6[0] = " ";
            }
        });
   }

    public void openDisplay() {
        Intent intent = new Intent(this, RecipeDisplay.class);
        startActivity(intent);
    }

    FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper(restriction[0]);
    firebaseDatabaseHelper.readRecipes(ingredient1, ingredient2, ingredient3, ingredient4, ingredient5, ingredient6);


}
