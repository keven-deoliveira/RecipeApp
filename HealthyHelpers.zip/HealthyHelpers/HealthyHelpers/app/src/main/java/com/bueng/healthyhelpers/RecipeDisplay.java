package com.bueng.healthyhelpers;

import com.bueng.healthyhelpers.RecipeSearch;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;

public class RecipeDisplay extends AppCompatActivity {

    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_recipe_display);
        mRecyclerView = (RecyclerView) findViewById(R.id.recycleview_recipes);

        //firebaseDatabaseHelper.recipes;

    }
}
