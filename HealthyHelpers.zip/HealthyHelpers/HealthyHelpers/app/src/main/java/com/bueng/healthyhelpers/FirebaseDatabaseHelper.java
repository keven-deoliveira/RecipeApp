package com.bueng.healthyhelpers;
import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.EventListener;
import java.util.List;

//This class is used to connect to firebase and access the database of recipes*/

public class FirebaseDatabaseHelper {
    private FirebaseDatabase mDatabase;
    private DatabaseReference mReferenceRecipes;
    public List<Recipe> recipes = new ArrayList<>(4); //array list of recipes to be displayed


    public interface DataStatus {
        void DataIsLoaded(List<Recipe> recipes, List<String> keys);
    }

    //Constructor, takes restriction as input to determine which library of recipes to search from
    public FirebaseDatabaseHelper(String restriction) {
        mDatabase = FirebaseDatabase.getInstance();
        if (restriction == "vegan") {
            mReferenceRecipes = mDatabase.getReference("vegan");
        }
        else if (restriction == "vegetarian") {
            mReferenceRecipes = mDatabase.getReference("vegetarian");
        }
        else {
            mReferenceRecipes = mDatabase.getReference("other");
        }
    }

    //Reads recipes from chosen library from above, checks to see if ingredients match
    public void readRecipes(final DataStatus dataStatus, final String ingredient1, final String ingredient2, final String ingredient3, final String ingredient4, final String ingredient5, final String ingredient6) {
        mReferenceRecipes.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                recipes.clear(); //clears old data
                List<String> keys = new ArrayList<>();
                for (DataSnapshot keyNode : dataSnapshot.getChildren()) { //goes through all recipes in specific library
                    keyNode.getKey();
                    Recipe recipe = keyNode.getValue(Recipe.class);
                    assert recipe != null;
                    String searchIngredients = recipe.ingredients;
                    int array_size = recipes.size();
                    if (array_size >= 4) {
                        break;
                    }
                    //All ingredients match
                    if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && searchIngredients.contains(ingredient3) && searchIngredients.contains(ingredient4) && searchIngredients.contains(ingredient5) && searchIngredients.contains(ingredient6)) {
                        recipes.add(recipe);
                        keys.add(keyNode.getKey());
                    }

                    //5 ingredients match
                    else if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && searchIngredients.contains(ingredient3) && searchIngredients.contains(ingredient4) && searchIngredients.contains(ingredient5) && array_size < 4) {
                        recipes.add(recipe);
                        keys.add(keyNode.getKey());
                    }

                    //4 ingredients match
                    else if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && searchIngredients.contains(ingredient3) && searchIngredients.contains(ingredient4) && array_size < 4) {
                        recipes.add(recipe);
                        keys.add(keyNode.getKey());
                    }

                    //3 ingredients match
                    else if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && searchIngredients.contains(ingredient3) && array_size < 4) {
                        recipes.add(recipe);
                        keys.add(keyNode.getKey());
                    }

                    //2 ingredients match
                    else if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && array_size < 4) {
                        recipes.add(recipe);
                        keys.add(keyNode.getKey());
                    }

                    //1 ingredient matches
                    else if (searchIngredients.contains(ingredient1) && array_size < 4) {
                        recipes.add(recipe);
                        keys.add(keyNode.getKey());
                    }
                }
                dataStatus.DataIsLoaded(recipes, keys);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

        });
    }
}

