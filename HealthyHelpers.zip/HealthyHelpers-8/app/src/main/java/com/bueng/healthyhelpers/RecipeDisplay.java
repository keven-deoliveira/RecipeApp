package com.bueng.healthyhelpers;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;


import android.view.View;

import java.util.List;

import static com.bueng.healthyhelpers.RecipeSearch.ingredient1;
import static com.bueng.healthyhelpers.RecipeSearch.ingredient2;
import static com.bueng.healthyhelpers.RecipeSearch.ingredient3;
import static com.bueng.healthyhelpers.RecipeSearch.ingredient4;
import static com.bueng.healthyhelpers.RecipeSearch.ingredient5;
import static com.bueng.healthyhelpers.RecipeSearch.ingredient6;
import static com.bueng.healthyhelpers.RecipeSearch.restriction;

public class RecipeDisplay extends AppCompatActivity {

    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_recipe_display);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview_recipes);
        new FirebaseDatabaseHelper(restriction[0]).readRecipes(new FirebaseDatabaseHelper.DataStatus() {
                                                                   @Override
                                                                   public void DataIsLoaded(List<Recipe> recipes, List<String> keys) {
                                                                       new RecyclerView_config().setConfig(mRecyclerView,
                                                                               RecipeDisplay.this, recipes, keys);
                                                                   }
                                                               },
                ingredient1[0], ingredient2[0], ingredient3[0],ingredient4[0], ingredient5[0],
                ingredient6[0]);
    }

}
