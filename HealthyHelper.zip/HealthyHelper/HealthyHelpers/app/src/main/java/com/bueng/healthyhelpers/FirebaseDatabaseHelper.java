package com.bueng.healthyhelpers;
import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.EventListener;
import java.util.List;

public class FirebaseDatabaseHelper {
    private FirebaseDatabase mDatabase;
    private DatabaseReference mReferenceRecipes;
    public List<Recipe> recipes = new ArrayList<>(4);

    public void readRecipes(DataStatus dataStatus) {
    }

    public interface DataStatus {
        void DataIsLoaded(List<Recipe> recipes, List<String> keys);
    }

    public FirebaseDatabaseHelper(String restriction) {
        mDatabase = FirebaseDatabase.getInstance();
        if (restriction == "vegan") {
            mReferenceRecipes = mDatabase.getReference("vegan");
        } else if (restriction == "vegetarian") {
            mReferenceRecipes = mDatabase.getReference("vegetarian");
        } else {
            mReferenceRecipes = mDatabase.getReference("other");
        }
    }

    public void readRecipes(final DataStatus dataStatus, final String ingredient1, final String ingredient2, final String ingredient3, final String ingredient4, final String ingredient5, final String ingredient6) {
        mReferenceRecipes.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                recipes.clear();
                List<String> keys = new ArrayList<>();
                for (DataSnapshot keyNode : dataSnapshot.getChildren()) {
                    keys.add(keyNode.getKey());
                    Recipe recipe = keyNode.getValue(Recipe.class);
                    assert recipe != null;
                    String searchIngredients = recipe.ingredients;
                    int arraysize = recipes.size();
                    if (arraysize >= 4) {
                        break;
                    }
                    //All ingredients match
                    if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && searchIngredients.contains(ingredient3) && searchIngredients.contains(ingredient4) && searchIngredients.contains(ingredient5) && searchIngredients.contains(ingredient6)) {
                        recipes.add(recipe);
                    }

                    //5 ingredients match
                    else if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && searchIngredients.contains(ingredient3) && searchIngredients.contains(ingredient4) && searchIngredients.contains(ingredient5) && arraysize < 4) {
                        recipes.add(recipe);
                    }

                    //4 ingredients match
                    else if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && searchIngredients.contains(ingredient3) && searchIngredients.contains(ingredient4) && arraysize < 4) {
                        recipes.add(recipe);
                    }

                    //3 ingredients match
                    else if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && searchIngredients.contains(ingredient3) && arraysize < 4) {
                        recipes.add(recipe);
                    }

                    //2 ingredients match
                    else if (searchIngredients.contains(ingredient1) && searchIngredients.contains(ingredient2) && arraysize < 4) {
                        recipes.add(recipe);
                    }

                    //1 ingredient matches
                    else if (searchIngredients.contains(ingredient1) && arraysize < 4) {
                        recipes.add(recipe);
                    }
                }
                dataStatus.DataIsLoaded(recipes, keys);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

        });
    }
}

