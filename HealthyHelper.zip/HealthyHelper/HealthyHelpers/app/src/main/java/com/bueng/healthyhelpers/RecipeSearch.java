package com.bueng.healthyhelpers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;

public class RecipeSearch extends AppCompatActivity {

    private CheckBox vgt, vg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_search);

        final String[] restriction = new String[1];

        Button btn2 = (Button) findViewById(R.id.button_recipe_find);

        //Set up button
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDisplay();
            }
        });

        // DIETARY RESTRICTIONS
        //View needs fixing

        vgt = findViewById(R.id.checkBoxvgt);
        vg = findViewById(R.id.checkBoxvg);

        restriction[0] = "other";

        vgt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(vgt.isChecked())
                    restriction[0] = "vegetarian";
            }
        });

        vg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(vg.isChecked())
                    restriction[0] = "vegan";
            }
        });
//
//        public void onCheckboxClicked(View view) {
//        // is view checked?
//        boolean checked = ((CheckBox) view).isChecked();
//            // check which checkbox was clicked
//            switch (view.getId()) {
//                case R.id.checkBoxvg: //VEGAN
//                    if (checked) {
//                        // only access vegan recipes
//                        restriction[0] = "vegan";
//                    } else {
//                        //access all recipes
//                        restriction[0] = "other";
//                    }
//                    break;
//                case R.id.checkBoxvgt: //VEGETARIAN
//                    if (checked) {
//                        // only access vegetarian recipes
//                        restriction[0] = "";
//                    } else {
//                        // access all recipes
//                        restriction[0] = "other";
//                    }
//                    break;
//            }
//        }

        //DASHBOARD FRAGMENT
        final Spinner spinner1 = findViewById(R.id.spinner2); //vegetables
        final String[] ingredient1 = new String[1];
        final Spinner spinner2 = findViewById(R.id.spinner); //proteins
        final String[] ingredient2 = new String[1];
        final Spinner spinner3 = findViewById(R.id.spinner3); //fruits
        final String[] ingredient3 = new String[1];
        final Spinner spinner4 = findViewById(R.id.spinner4); //nuts and seeds
        final String[] ingredient4 = new String[1];
        final Spinner spinner5 = findViewById(R.id.spinner5); //dairy and alternatives
        final String[] ingredient5 = new String[1];
        final Spinner spinner6 = findViewById(R.id.spinner6); //carbohydrates
        final String[] ingredient6 = new String[1];

        // VEGETABLES
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(RecipeSearch.this,
                R.layout.activity_recipe_search, getResources().getStringArray(R.array.vegetables_array));
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient1[0] = spinner1.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });

        // PROTEINS
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(RecipeSearch.this,
                R.layout.activity_recipe_search, getResources().getStringArray(R.array.protein_array));
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient2[0] = spinner2.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });

        // FRUITS
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(RecipeSearch.this,
                R.layout.activity_recipe_search, getResources().getStringArray(R.array.fruit_array));
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter3);
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient3[0] = spinner3.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });

        // NUTS AND SEEDS
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(RecipeSearch.this,
                R.layout.activity_recipe_search, getResources().getStringArray(R.array.nuts_array));
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner4.setAdapter(adapter4);
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient4[0] = spinner4.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });

        // DAIRY AND ALTERNATIVES
        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(RecipeSearch.this,
                R.layout.activity_recipe_search, getResources().getStringArray(R.array.dairy_array));
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner5.setAdapter(adapter5);
        spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient5[0] = spinner5.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });

        //  CARBOHYDRATES
        ArrayAdapter<String> adapter6 = new ArrayAdapter<String>(RecipeSearch.this,
                R.layout.activity_recipe_search, getResources().getStringArray(R.array.carbs_array));
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner6.setAdapter(adapter6);
        spinner6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient6[0] = spinner6.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });
    }

    public void openDisplay() {
        Intent intent = new Intent(this, RecipeDisplay.class);
        startActivity(intent);
    }
}
