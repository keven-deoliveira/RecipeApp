package com.bueng.healthyhelper;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.List;

public class RecyclerView_config {
    private Context mContext;
    private recipeAdapter mRecipeAdapter;
    public void setConfig(RecyclerView recyclerView, Context context, List<Recipe>  recipes,
                          List<String> keys) {
        mContext = context;
        mRecipeAdapter = new recipeAdapter(recipes, keys);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setAdapter(mRecipeAdapter);
    }

    class RecipeItemView extends RecyclerView.ViewHolder {
        private TextView mName;
        private TextView mIngredients;
        private TextView mSteps;

        private String key;

        public RecipeItemView(ViewGroup parent) {
            super(LayoutInflater.from(mContext).inflate(R.layout.recipe_list_item, parent,
                    false));

            mName = (TextView) itemView.findViewById(R.id.recipeName_textView);
            mIngredients = (TextView) itemView.findViewById(R.id.recipeIngredients_textView);
            mSteps = (TextView) itemView.findViewById(R.id.recipeSteps_textView);
        }

        public void Bind(Recipe recipe, String key) {
            mName.setText(recipe.recipeName);
            mIngredients.setText(recipe.userIngredients);
            mSteps.setText(recipe.instructions);
            this.key = key;
        }
    }

    class recipeAdapter extends RecyclerView.Adapter<RecipeItemView> {
        private List<Recipe> mRecipeList;
        private List<String> mKeys;

        public recipeAdapter(List<Recipe> mRecipeList, List<String> mKeys) {
            this.mRecipeList = mRecipeList;
            this.mKeys = mKeys;
        }

        @NonNull
        @Override
        public RecipeItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new RecipeItemView(parent);
        }

        @Override
        public void onBindViewHolder(@NonNull RecipeItemView holder, int position) {
            holder.Bind(mRecipeList.get(position), mKeys.get(position));

        }

        @Override
        public int getItemCount() {
            return mRecipeList.size();
        }
    }
}
