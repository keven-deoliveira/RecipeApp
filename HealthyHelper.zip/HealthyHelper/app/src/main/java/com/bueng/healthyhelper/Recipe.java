package com.bueng.healthyhelper;

public class Recipe {
    public String recipeName;       //name of recipe
    public String ingredients;      //ingredients list
    public String ingredientVals;   //ingredients with measurements
    public String fullRecipe;       //recipe
    public String category;         //vegetarian, vegan, other

    public Recipe(){
    }

    public Recipe(String recipeName, String ingredients, String ingredientVals, String fullRecipe, String category) {
        this.recipeName = recipeName;
        this.ingredients = ingredients;
        this.ingredientVals = ingredientVals;
        this.fullRecipe = fullRecipe;
        this.category = category;
    }

    public String getRecipeName() {
        return recipeName;
    }

    public String getIngredients() {
        return ingredients;
    }

    public String getIngredientVals() {
        return ingredientVals;
    }

    public String getFullRecipe() {
        return fullRecipe;
    }

    public String getCategory() {
        return category;
    }
}
