package com.bueng.healthyhelper;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;

import com.bueng.healthyhelper.ui.dashboard.DashboardFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_view);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        //DASHBOARD FRAGMENT
        // (ingredient selection)
        final Spinner spinner1 = findViewById(R.id.spinner2); //vegetables
        final String[] ingredient1 = new String[1];
        final Spinner spinner2 = findViewById(R.id.spinner); //proteins
        final String[] ingredient2 = new String[1];
        final Spinner spinner3 = findViewById(R.id.spinner3); //fruits
        final String[] ingredient3 = new String[1];
        final Spinner spinner4 = findViewById(R.id.spinner4); //nuts and seeds
        final String[] ingredient4 = new String[1];
        final Spinner spinner5 = findViewById(R.id.spinner5); //dairy and alternatives
        final String[] ingredient5 = new String[1];
        final Spinner spinner6 = findViewById(R.id.spinner6); //carbohydrates
        final String[] ingredient6 = new String[1];
        // VEGETABLES
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(MainActivity.this,
                R.layout.fragment_dashboard, getResources().getStringArray(R.array.vegetables_array));
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // return ingredient selected as a string
                ingredient1[0] = spinner1.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });
        // PROTEINS
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(MainActivity.this,
                R.layout.fragment_dashboard, getResources().getStringArray(R.array.protein_array));
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // return ingredient selected as a string
                ingredient2[0] = spinner2.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });
        // FRUITS
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(MainActivity.this,
                R.layout.fragment_dashboard, getResources().getStringArray(R.array.fruit_array));
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter3);
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient3[0] = spinner3.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });
        // NUTS AND SEEDS
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(MainActivity.this,
                R.layout.fragment_dashboard, getResources().getStringArray(R.array.nuts_array));
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner4.setAdapter(adapter4);
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient4[0] = spinner4.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });
        // DAIRY AND ALTERNATIVES
        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(MainActivity.this,
                R.layout.fragment_dashboard, getResources().getStringArray(R.array.dairy_array));
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner5.setAdapter(adapter5);
        spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient5[0] = spinner5.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });
        //  CARBOHYDRATES
        ArrayAdapter<String> adapter6 = new ArrayAdapter<String>(MainActivity.this,
                R.layout.fragment_dashboard, getResources().getStringArray(R.array.carbs_array));
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner6.setAdapter(adapter6);
        spinner6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // access the ingredients from recipes
                ingredient6[0] = spinner6.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // if no element from that category is chosen nothing should happen
            }
        });


        }

    }
