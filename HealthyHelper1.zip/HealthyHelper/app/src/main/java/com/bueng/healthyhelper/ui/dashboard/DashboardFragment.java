package com.bueng.healthyhelper.ui.dashboard;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.ArrayRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.bueng.healthyhelper.R;

public class DashboardFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;

    public DashboardFragment() {

    }

    public View onCreateView(@NonNull final LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_dashboard, container, false);

        dashboardViewModel =
                ViewModelProviders.of(this).get(DashboardViewModel.class);
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
        final TextView textView = root.findViewById(R.id.navigation_dashboard);
        dashboardViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }

            // DIETARY RESTRICTIONS
            public void onCheckBoxClicked(View view) {
                // is view checked?
                boolean checked = ((CheckBox) view).isChecked();
                // check which checkbox was clicked
                switch (view.getId()) {
                    case R.id.checkBox: //VEGAN
                        if (checked) {
                            // only access vegan recipes
                        }
                        else {
                            //access all recipes
                        }
                        break;
                    case R.id.checkBox2: //VEGETARIAN
                        if (checked) {
                            // only access vegetarian recipes
                        }
                        else {
                            // access all recipes
                        }
                        break;
                }

            }

        });

        return root;
    }


}


